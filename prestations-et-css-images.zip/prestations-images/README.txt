Images attendues dans assets :
administratif.png
E2.jpg
E1.jpg
A1.jpg
A3.jpg
A2.jpg
